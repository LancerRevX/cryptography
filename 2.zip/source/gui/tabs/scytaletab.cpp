#include "scytaletab.hpp"
#include "ui_scytaletab.h"

#include <ciphers.hpp>

#include <QDebug>

ScytaleTab::ScytaleTab(QWidget* parent) : QWidget(parent), ui(new Ui::ScytaleTab) {
    ui->setupUi(this);
    auto rodFacesNumber = ui->rodFacesEdit->value();
    auto rodCharLength = ui->rodCharLengthEdit->value();
    ui->messageEdit->setMaxLength(rodFacesNumber * rodCharLength);
    ui->codeEdit->setMaxLength(rodFacesNumber * rodCharLength);
    ui->codeTable->setColumnCount(rodCharLength);
    ui->codeTable->setRowCount(rodFacesNumber);
}

ScytaleTab::~ScytaleTab() {
    delete ui;
}

void ScytaleTab::on_messageEdit_textEdited(const QString&) {
    this->encodeMessage();
}

void ScytaleTab::on_codeEdit_textEdited(const QString&) {
    this->decodeMessage();
}

void ScytaleTab::on_rodFacesEdit_valueChanged(int rodFacesNumber) {
    ui->codeTable->setRowCount(rodFacesNumber);

    ui->messageEdit->setMaxLength(rodFacesNumber * ui->rodCharLengthEdit->value());
    ui->codeEdit->setMaxLength(rodFacesNumber * ui->rodCharLengthEdit->value());

    this->encodeMessage();
}

void ScytaleTab::on_rodCharLengthEdit_valueChanged(int rodCharLength) {
    ui->codeTable->setColumnCount(rodCharLength);

    ui->messageEdit->setMaxLength(rodCharLength * ui->rodFacesEdit->value());
    ui->codeEdit->setMaxLength(rodCharLength * ui->rodFacesEdit->value());

    this->encodeMessage();
}

void ScytaleTab::on_switchButton_clicked() {
    ui->messageEdit->setText(ui->codeEdit->text());
    this->encodeMessage();
}

void ScytaleTab::encodeMessage()
{
    auto message = ui->messageEdit->text();
    auto rodFacesNumber = ui->rodFacesEdit->value();
    auto rodCharLength = ui->rodCharLengthEdit->value();
    auto code = QString::fromStdWString(scytale::encode(
        message.toStdWString(),
        rodFacesNumber,
        rodCharLength
    ));
    ui->codeEdit->setText(code);
    for (int i = 0; i < rodFacesNumber; i += 1) {
        for (int j = 0; j < rodCharLength; j += 1) {
            ui->codeTable->setItem(
                i, j, new QTableWidgetItem(QString(code[i + j*rodFacesNumber]))
            );
        }
    }
}

void ScytaleTab::decodeMessage() {
    auto code = ui->codeEdit->text();
    auto rodFacesNumber = ui->rodFacesEdit->value();
    auto rodCharLength = ui->rodCharLengthEdit->value();
    auto message = QString::fromStdWString(scytale::decode(
        code.toStdWString(),
        rodFacesNumber,
        rodCharLength
    ));
    qDebug() << message;
    ui->messageEdit->setText(message);
    for (int i = 0; i < rodFacesNumber; i += 1) {
        for (int j = 0; j < rodCharLength; j += 1) {
            ui->codeTable->setItem(
                i, j, new QTableWidgetItem(QString(message[j + i*rodCharLength]))
            );
        }
    }
}

