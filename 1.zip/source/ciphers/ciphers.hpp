#pragma once

#include <string>

namespace atbash {
    std::wstring encode(const std::wstring& message);
}
