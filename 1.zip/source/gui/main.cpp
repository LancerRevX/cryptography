#include "mainwindow.h"

#include <QApplication>
#include <QDebug>
#include <QRegExp>

int main(int argc, char *argv[]) {
    QApplication aplication(argc, argv);
    MainWindow window;
    window.show();
    return aplication.exec();
}
